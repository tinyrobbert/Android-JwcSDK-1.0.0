package com.example.jwcsdkdemo;

import org.apache.http.impl.client.DefaultHttpClient;

import android.app.Application;

/**
 * ȫ�ֱ���
 * 
 * @author Adamearth
 *
 */
public class JwcApplication extends Application{
	
	public static JwcApplication THIS;
	
	public DefaultHttpClient httpClient = new DefaultHttpClient();
	
	//����ʱ����
    public void onCreate(){
	     super.onCreate();       	     
	     THIS = this;	        
    }
}
